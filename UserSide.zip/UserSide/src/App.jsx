import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Indexs from './Components/Indexs'
import Login from './Components/Login';
import DsignUp from './Components/Doctor/DsignUp';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <Router>
      <Routes>
        <Route path="/" element={<Indexs />} />
        <Route path="/login" element={<Login />} />
        <Route path="/docs" element={<DsignUp />} />
      </Routes>
     </Router>
    </>
  )
}

export default App
